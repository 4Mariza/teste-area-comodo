package br.senai.sp.jandira;

import java.util.Scanner;

public class AreaCalculo {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
			String comodo, resposta = "S";
			Double largura, comprimento, area, areaTotal = 0.0;
		
			System.out.println("-----------------------------------------");
			System.out.println("     C A L C U L A N D O  Á R E A S   ");
			System.out.println("-----------------------------------------");
			System.out.println("");
		
		for(;resposta.equals("S") || resposta.equals("sim") || resposta.equals("Sim") || resposta.equals("s");){
			System.out.print("Insira o nome do cômodo que deseja calcular: ");
			comodo = teclado.next();
			System.out.println("");
			
			System.out.print("Insira a largura de " + comodo + ": ");
			largura = teclado.nextDouble();
			System.out.println("");
			
			System.out.print("Insira o comprimento de " + comodo + ": ");
			comprimento = teclado.nextDouble();
			System.out.println("");
			
			area = largura * comprimento;
			System.out.println("-----------------------------------------");
			System.out.println("");
			
			System.out.println("A área de " + comodo + " é: " + area + " metros quadrados");
			System.out.println("");
			
			System.out.println("Deseja cadastrar mais um cômodo? (S/N)");
			resposta = teclado.next();
			System.out.println("");
			System.out.println("-----------------------------------------");
			
			areaTotal += area;
		}
		
		System.out.println(" A área total dos cômodos inseridos é de: " + areaTotal + " metros quadrados.");
	}

}
